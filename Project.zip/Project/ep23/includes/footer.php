<?php include("config.php");?>

</div>

<!--BEGIN FOOTER-->

<div id="footer">

    <div class="copyright"><?php echo TXDIRECT;?></div>

</div><!--END FOOTER-->

</div><!--END PAGE WRAPPER-->



</div>





<!--loading bootstrap js-->

<script src="<?php echo ASSETS_PATH_JS ?>vendors/bootstrap-hover-dropdown/bootstrap-hover-dropdown.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>js/html5shiv.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>js/respond.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/metisMenu/jquery.metisMenu.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/slimScroll/jquery.slimscroll.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/jquery-cookie/jquery.cookie.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/iCheck/icheck.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/iCheck/custom.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/jquery-notific8/jquery.notific8.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/jquery-highcharts/highcharts.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>js/jquery.menu.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/jquery-pace/pace.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/holder/holder.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/responsive-tabs/responsive-tabs.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/jquery-news-ticker/jquery.newsTicker.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/moment/moment.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/jquery-toastr/toastr.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>js/ui-toastr-notifications.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>custom/bootbox.min.js"></script>



<script src="<?php echo ASSETS_PATH_JS ?>js/bootstrap-notify.min.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>js/bootstrap-notify.js"></script>

<!--CORE JAVASCRIPT-->

<script src="<?php echo ASSETS_PATH_JS ?>js/main.js"></script>

<!--LOADING SCRIPTS FOR PAGE-->



<!-- scripts for datatables -->

<script type="text/javascript" src="<?php echo ASSETS_PATH_JS ?>DataTables/datatables.js"></script>

<script type="text/javascript" src="<?php echo ASSETS_PATH_JS ?>DataTables/DataTables-1.10.16/js/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="<?php echo ASSETS_PATH_JS ?>DataTables/DataTables-1.10.16/js/dataTables.bootstrap.min.js"></script>



<script src="<?php echo ASSETS_PATH_JS; ?>vendors/bootstrap-select/bootstrap-select.min.js"></script>

<!-- custom ajax call -->

<script src="<?php echo ASSETS_PATH_JS ?>custom/ajaxcall.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/ckeditor/ckeditor.js"></script>

<script src="<?php echo ASSETS_PATH_JS ?>vendors/ckeditor/bootstrap-ckeditor-fix.js"></script>



<script type="text/javascript">

$(function() {

});

</script>