<?php include("config.php");?>
<?php include(ROOT_PATH."classes/CRUD_Class.php");?>
<?php
	$crud = new CRUD;
?> 
	 
 