<?php 
	$currentFile = $_SERVER["SCRIPT_NAME"];
	$parts = Explode('/', $currentFile);
	$currentFile = $parts[count($parts) - 1];    
	$settings 	 = array('');  
?>
<div id="wrapper"><!--BEGIN SIDEBAR MENU-->
        <nav id="sidebar" role="navigation" class="navbar-default navbar-static-side">
            <div class="sidebar-collapse menu-scroll">
                <ul id="side-menu" class="nav">
                    <li class="user-panel">
                        <div class="hidden thumb">
                            <img src="" alt="" class="img-circle"/></div>
                        <div class="info"><p><?php if(isset($_SESSION['admin_name'])) echo $_SESSION['admin_name'];?></p>
                            <ul class="list-inline list-unstyled">
                                <?php //<li><a href="profile.php" data-hover="tooltip" title="Profile"><i class="fa fa-user"></i></a></li> ?>
                                <?php /*?><li><a href="#" data-hover="tooltip" title="Setting" data-toggle="modal" data-target="#modal-config"><i class="fa fa-cog"></i></a></li><?php */?>
                                <?php /*<li><a href="<?php echo API_PATH; ?>logout.php" data-hover="tooltip" title="Logout"><i
                                        class="fa fa-sign-out"></i></a></li>*/ ?>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </li>
                   <?php /*?> <li><a href="#"><i class="fa fa-tachometer fa-fw">
                        <div class="icon-bg bg-orange"></div>
                    </i><span class="menu-title">Dashboard</span></a></li><?php */?>
                    <li <?php if($currentFile=="user_list.php" or $currentFile=="user_list.php"){?>class="active"<?php }?>>
								<a href="<?php echo BASE_PATH; ?>user_list.php"><i class="fa fa-list"></i><span  class="menu-title">User List</span></a>
							</li>

                    
                    </ul>
            </div>
        </nav>
        <!--END SIDEBAR MENU-->


<!--BEGIN PAGE WRAPPER-->
<div id="page-wrapper">
<div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
	<div class="page-header mlxl">
		<div class="page-title" style="text-shadow: 0px 0px gray;" id="orgTitle"></div>
	</div>
</div>
