<?php
error_reporting(E_ALL);
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$timezone = "Asia/Calcutta";
if(function_exists('date_default_timezone_set')) @date_default_timezone_set($timezone);


//User types
if (!defined('ADMIN')) 				define("ADMIN","admin");


//Table Names
if (!defined('ADMIN_MASTER')) 		define('ADMIN_MASTER','admin');

//Shortforms
if (!defined('TXDIRECT')) 			define('TXDIRECT',"2019 Door opener using fingerprint. All Rights Reserved.");

if (!defined('DOMAIN_NAME')) 		define('DOMAIN_NAME','https://'.$_SERVER['SERVER_NAME'].'/');
if (!defined('SIGNATURE')) 			define('SIGNATURE',"The Team");

// define paths
if (!defined('ROOT_PATH')) 			define("ROOT_PATH", $_SERVER["DOCUMENT_ROOT"].'/ep23/'); 
if (!defined('ABSPATH')) 			define('ABSPATH', dirname(__FILE__) . '/');
if (!defined('BASE_PATH')) 			define('BASE_PATH', 'http://'.$_SERVER['SERVER_NAME'].'/ep23/');
if (!defined('ASSETS_PATH_CSS')) 	define('ASSETS_PATH_CSS', BASE_PATH.'assets/');
if (!defined('ASSETS_PATH_JS')) 	define('ASSETS_PATH_JS', BASE_PATH.'assets/');
if (!defined('IMAGES_PATH')) 		define('IMAGES_PATH', BASE_PATH. 'assets/images/');
if (!defined('INCLUDE_FILE_PATH')) 	define('INCLUDE_FILE_PATH', ROOT_PATH. '/includes/');
if (!defined('FILE_UPLOAD_PATH')) 	define('FILE_UPLOAD_PATH', ROOT_PATH. '/uploads/');
if (!defined('API_PATH')) 			define('API_PATH', BASE_PATH. 'api/');
if (!defined('PAGE_TITLE')) 		define('PAGE_TITLE', 'Door Opener Using Fingerprint');

//define emails


//buttons
$view_button = '<a class="btn btn-view" href="" title="View Details" aria-label="View Details" lang="[[id]]"><i class="fa fa-eye" aria-hidden="true" style="color: #2196F3;"></i></a>';

$edit_button = '<a class="btn btn-edit" href="index.php?update&id=[[id]]" title="Edit" aria-label="Edit"><i class="fa fa-edit" aria-hidden="true" style="color: blue;"></i></a>';    

$delete_button = '<a class="btn btn-delete" href="" aria-label="Delete" lang="[[id]]" title="Delete" style="color:red"> <i class="fa fa-trash-o" aria-hidden="true"></i></a>';



$footer_copyright = '<div>&copy; '.TXDIRECT.'</div>';

$htmlhead = '';

//header( 'Content-Type: text/html; charset=utf-8' );

?>