<?php include("includes/connection.php");?>
<div class="panel panel-orange mbn">
	<div class="panel-heading">Add User</div>
	<div class="panel-body pan">
		<div class="portlet box">
			<div class="portlet-body">
				<form  class="horizontal-form form-seperated form-horizontal" method="POST" id="create-form">
						<div class="row">
							<div class="form-body">
							                    
							<div class="form-group  text-dark">
								<label for="ciName" class="control-label col-md-3 text-right fs-14 ">Name<span class='require'>*</span></label>
								<div class="col-md-6">
									<input type="text" class="form-control" id="name" name="name" value=''/>
									<span class="error-msg" id="err_name" >
									<i class="fa fa-exclamation-circle"></i></span>
									</div>
									
								
							</div>                   

							<div class="form-group  text-dark date-div">
								<label for="couponsMobile" class="control-label col-md-3 text-right fs-14 ">Contact Number</label>
								<div class="col-md-6">
									<input type="text" class="form-control" id="mobile" name="mobile" value=''/>
									<span class="error-msg" id="err_mobile" >
									<i class="fa fa-exclamation-circle"></i></span>
									
								</div>
							</div>  
							<div class="form-group  text-dark">
                            	<label for="couponsMobile" class="control-label col-md-3 text-right fs-14 ">User Name<span class='require'>*</span></label>
								<div class="col-md-6 ">
                                	<input type="text" class="form-control" id="userName" name="userName" value=''/>
                                   
									<span class="error-msg" id="err_userName" >
									<i class="fa fa-exclamation-circle"></i></span>
								</div>
							</div> 
                            <div class="form-group  text-dark">
								<label for="couponsMobile" class="control-label col-md-3 text-right fs-14 ">Password<span class='require'>*</span><span class='require'>*</span></label>
								<div class="col-md-6">
                                	<input type="text" class="form-control" id="password" name="password" value=''/>
									<span class="error-msg" id="err_password" >
									<i class="fa fa-exclamation-circle"></i></span>
								</div>
							</div> 
                            <div class="form-group  text-dark">
                            	<label for="couponsMobile" class="control-label col-md-3 text-right fs-14 ">FingerPrint Id<span class='require'>*</span></label>
								<div class="col-md-6">
                                    <input type="text" class="form-control" id="idNo" name="idNo" value=''/>
									<span class="error-msg" id="err_idNo" >
									<i class="fa fa-exclamation-circle"></i></span>
								</div>
							</div>    

						</div>
					</div>
					<div class="form-actions text-right pal">										
						<a href="" id="cancel" data-dismiss="modal" class="btn btn-grey">Cancel</a>
						<a id="<?php if(isset($_POST['lId'])) echo 'btn-update'; else echo 'btn-save'; ?>" class="btn btn-success"><?php if(isset($_POST['lId'])) echo 'Edit'; else echo 'Add';?></a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>