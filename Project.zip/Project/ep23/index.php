<?php include("includes/config.php");
if(isset($_SESSION['admin_name']))
	{
		header( "Location:user_list.php");
		exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head><title>Admin | Login</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="Thu, 19 Nov 1900 08:52:00 GMT">
    <!--Loading bootstrap css-->
    <link type="text/css"
          href="https://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,800italic,400,700,800">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet"
        href="<?php echo ASSETS_PATH_CSS ?>vendors/jquery-ui-1.10.4.custom/css/ui-lightness/jquery-ui-1.10.4.custom.min.css">
    <link type="text/css" rel="stylesheet" 
        href="assets/vendors/font-awesome/css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" 
        href="<?php echo ASSETS_PATH_CSS ?>vendors/bootstrap/css/bootstrap.min.css">
    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="<?php echo ASSETS_PATH_CSS ?>vendors/animate.css/animate.css">
    <link type="text/css" rel="stylesheet" href="<?php echo ASSETS_PATH_CSS ?>vendors/iCheck/skins/all.css">
    <!--Loading style-->
    <link type="text/css" rel="stylesheet" 
        href="<?php echo ASSETS_PATH_CSS ?>css/themes/style1/blue-grey.css" class="default-style">
    <link type="text/css" rel="stylesheet" 
        href="<?php echo ASSETS_PATH_CSS ?>css/themes/style1/blue-grey.css" id="theme-change"
          class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="<?php echo ASSETS_PATH_CSS ?>css/style-responsive.css">
    <link rel="shortcut icon" href="<?php echo ASSETS_PATH_CSS ?>images/favicon.ico">
<style>
#signin-page{
	background:none!important;
	background-color:#fff!important;
}
</style>
</head>
<body id="signin-page">
<div class="page-form">
    <form action="" class="form" id="create-form">
        <div class="header-content"><h1>Log In</h1></div>
        <div class="body-content">

            <div class="form-group">
                <div class="input-icon right"><i class="fa fa-user"></i>
				<input type="text" placeholder="Username" id="username" name="username" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <div class="input-icon right"><i class="fa fa-key"></i>
				<input type="password" placeholder="Password" id="password" name="password" class="form-control">
                </div>
            </div>
            <div class="invildemail" style="color:#FF0000; font-size:14px; display:none; margin-top: -15px; ">
			  <span id="emailError" style="color:#FF0000; margin-left:10px;float:left;margin-top: 8px; ">
							Invalid email or password!				
						</span>
			</div>
			<div class="clearfix">
            
        	</div>
            <div class="form-group pull-right">
                <a class="btn btn-success" id="btn-login">Log In
                    &nbsp;<i class="fa fa-chevron-circle-right"></i></a>
            </div>
            <div class="clearfix"></div>
            
    </form>
</div>
<script src="<?php echo ASSETS_PATH_JS ?>js/jquery-1.10.2.min.js"></script>
<script src="<?php echo ASSETS_PATH_JS ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo ASSETS_PATH_JS ?>js/jquery-ui.js"></script>
<!--loading bootstrap js-->
<script src="<?php echo ASSETS_PATH_JS ?>vendors/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo ASSETS_PATH_JS ?>vendors/bootstrap-hover-dropdown/bootstrap-hover-dropdown.js"></script>
<script src="<?php echo ASSETS_PATH_JS ?>js/html5shiv.js"></script>
<script src="<?php echo ASSETS_PATH_JS ?>js/respond.min.js"></script>
<script src="<?php echo ASSETS_PATH_JS ?>vendors/iCheck/icheck.min.js"></script>
<script src="<?php echo ASSETS_PATH_JS ?>vendors/iCheck/custom.min.js"></script>
<script>
jQuery(document).ready(function(){
	//BEGIN CHECKBOX & RADIO
	$('input[type="checkbox"]').iCheck({
		checkboxClass: 'icheckbox_minimal-grey',
		increaseArea: '20%' // optional
	});
	$('input[type="radio"]').iCheck({
		radioClass: 'iradio_minimal-grey',
		increaseArea: '20%' // optional
	});
	//END CHECKBOX & RADIO
	$("body").on("keyup","#username, #password",function(event){	
		 if (event.which == 13 || event.keyCode == 13) {
        //code to execute here
			 $('#btn-login').trigger('click');
		}
		return true;
	});
	
	$("body").on("click","#btn-login",function(){	
		var username = $("#username").val();
		var password = $("#password").val();
		if ($.trim(username) == "") 
		{	
			$("#username").addClass('error_border');
			$("#username").focus();
			return false;
		}
		else
		{
			$("#username").removeClass('error_border');
		}
		if ($.trim(password) == "") 
		{	
			$("#password").addClass('error_border');
			$("#password").focus();
			return false;
		}
		else
		{
			$("#password").removeClass('error_border');
		}
		var datastring=$("#create-form").serialize();
			 $.ajax({
				type: 'POST',
				url: '<?php echo API_PATH; ?>login.php',
				data:datastring,
				success:function(data){ 
					//alert(data);
					//exit();
					if($.trim(data)=="Valid"){
						 var wheretogo =  '<?php echo BASE_PATH; ?>user_list.php';
						 window.location.replace(wheretogo);
					}
					else
					{
						$(".invildemail").fadeIn(500).fadeOut(5000)
					}
				},
				error: function(data) { 
					alert("Error occured.please try again".data);
				}
			 });
	});
});
</script>


</body>
</html>