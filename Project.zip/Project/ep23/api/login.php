<?php include("../includes/config.php");?>
<?php include("../includes/connection.php");
	 

	$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
	$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

	  
	if($username=="")
	{
		echo "Empty"; 
		exit;
		 
	}
	else if($password=="")
	{
		echo "Empty"; 
		exit;		 
	}	 
	else
	{
		
		$condition = array("select"=>'*',"where"=> array(
									   "userName"=>$username,
									   "password"=>$password)
					);
		
		$result		=		$crud->getRows('tbl_door_opner_user',$condition);
		if(sizeof($result) > 0)
		{ 
			//session_start();
			foreach($result as $row){
				$_SESSION['id']=$row['id'];
				$_SESSION['admin_name']=$row['userName'];
			}
			echo 'Valid';
			exit;
				
		}
		else
		{
			echo 'Invalid';
			exit;
			 
		}
	}
	
	
	


?> 