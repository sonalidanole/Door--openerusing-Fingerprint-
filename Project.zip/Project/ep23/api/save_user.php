<?php include("../includes/config.php");?>
<?php include(ROOT_PATH."includes/connection.php");
error_reporting (E_ALL ^ E_NOTICE);
	$name			= $_POST['name'];
	$mobile 		= $_POST['mobile'];
	$userName 		= $_POST['userName'];
	$password 		= $_POST['password'];
	$idNo 			= $_POST['idNo'];
	$data			= array(
							"name"=>$name,
							"mobile"=>$mobile,
							"userName"=>$userName,
							"password"=>$password,
							"idNo"=>$idNo
							);
	
	if ($crud->insert('tbl_door_opner_user',$data)){
			echo 'Inserted';
		}
	else{
			echo 'Error';
		}
		
?>