<?php include("../includes/config.php");?>
<?php include(ROOT_PATH."includes/connection.php");
error_reporting (E_ALL ^ E_NOTICE);
	$id			= $_POST['id'];
	$data			= array(
							"isAcitve"=>1
							);
	$condition	= array(
							"id"=>$id
							);
	if ($crud->update('tbl_door_opner_user',$data,$condition)){
			echo 'Deleted';
		}
	else{
			echo 'Error';
		}
		
?>
