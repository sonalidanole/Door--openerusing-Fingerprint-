$(function () {
    var spinner = $( ".spinner" ).spinner();
});


