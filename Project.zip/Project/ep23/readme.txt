Changes in includes/config.php
Step 1
Change basepath
Change DOMAIN_NAME. Change last folder name.(For this project we have used student_info)
Change ROOT_PATH. Change last folder name.(For this project we have used student_info)
Change BASE_PATH. Change last folder name.(For this project we have used student_info)

Step 2
Change Copy right text.
Change TXDIRECT text.

Step 3
Change Copy right text.
Change PAGE_TITLE.