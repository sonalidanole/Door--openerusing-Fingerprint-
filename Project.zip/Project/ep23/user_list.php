<?php include("includes/config.php"); ?>
<?php include("includes/header.php");?>
<?php include("includes/topbar.php");?>
<?php include("includes/sidebar.php");?>
<?php include("includes/connection.php");?>
<?php
	error_reporting(0);
	$userId			= $_SESSION['id'];
	$condition	= array("select"=>'*',
						"where"=>array("userType"=>1,"isAcitve"=>0)
					   );
	$result		= $crud->getRows('tbl_door_opner_user',$condition); 
?> 
<div class="page-content">
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-body ptn">
					<div class="row">
						<div class="col-lg-12">
							<div class="portlet box pbot">
								<div class="portlet-header">

									<div class="row">
									</div>

									<div class="row mtl">
										<div class="col-md-3">
											<label>
												<div class="input-group input-group-sm mbs">
													<div id="search_error" style="display:none;color:#FF0000">Please enter search text</div>
												</div>
											</label>
										</div>
										<div class="actions"> <!--id="btn-add-new"--> 
                       
                                            <a class="btn btn-info" id="btn-add">
												<i class="fa fa-plus"></i>&nbsp;Add New
											</a>&nbsp;	
                                            
										</div>
									</div>
								</div>
							</div>
							<div class="portlet box">

								<div class="portlet-body">
									<div id="users-grid" class="grid-view">
											<table id="example" class="table table-bordered" cellspacing="0" width="100%">
												<thead>
													<tr>
														<th width="5%">ID</th>
														<th >Name</th>
                                                        <th >Contact Number</th>
                                                        <th >User Name </th>
                                                        <th >Action</th>

													</tr>
												</thead>
												<tbody>
                                                	<?php 
													if(sizeof($result)>0){
														$i = 0;
														foreach($result as $row){
															$i++;
                                                    ?>
															<tr>
																<td><?php echo $i;?></td>
																<td><?php echo $row['name'];?></td>
																<td><?php echo $row['mobile'];?></td>
																<td><?php echo $row['userName'];?></td>
																<td>
																	<a class="btn btn-delete delete" lang="<?php echo $row['id']; ?>" aria-label="Delete" title="Delete">
																				  <i class="fa fa-trash-o" aria-hidden="true"></i>
																	</a>
																</td>
															 </tr>
                                                    <?php }
													}?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
<input type="hidden" id="final-pId" name="final-pId" value="0"/>
<!--END CONTENT-->
</div>    
 <!--add new modal-->
<div id="modal-list" tabindex="-1" role="dialog" aria-labelledby="modal-wide-width-label" aria-hidden="true" class="modal fade mt50">
    <div class="modal-dialog modal-wide-width" style="width:85%!important;">
        <div class="modal-content">
            <div class="modal-body" >
            			
            </div>
        </div>
    </div>
</div>  
<?php include("includes/footer.php");?>
<script>
jQuery(document).ready(function(){


	$("#orgTitle").html('User List');
	oTable = $('#example').dataTable({
				"bJQueryUI": true,
				"responsive": true,
				"bStateSave":true,
				"aaSorting": [[0,"asc"]],
				"sPaginationType": "full_numbers",
				"iDisplayLength": 10,
				"aoColumns": [
				{ "bSortable": true },
				{ "bSortable": true },
				{ "bSortable": true },
				{ "bSortable": true },
				{ "bSortable": false }
				]
		});
	$("#example").attr("style","");
	$("th").attr("style","");

	$("body").on("click","#btn-add",function(){

		$("#wait").css("display", "block");
		
			$.ajax({
				type: 'POST',
				url: '<?php echo BASE_PATH; ?>add_user.php',
				success:function(data){ 
					$("#wait").css("display", "none");
					$(".modal-body").html(data);
					$("#modal-list").modal();
                    setTimeout(function(){ 	
					   CKEDITOR.replace( 'message', {
                            fullPage: true,
                            // Disable content filtering because if you use full page mode, you probably
                            // want to  freely enter any HTML content in source mode without any limitations.
                            allowedContent: true,
                            height: 320
                        } );
                    },1000);                    
				},
				error: function(data) { 
					alert("Error occured.please try again".data);
				}
				
			 });	
	});
	$("body").on("click",".btn-delete",function(){
		var id = $(this).attr('lang');
		bootbox.confirm({
			title: "Delete User.",
			message: "Do you want to delete this record?",
			buttons: {
				cancel: {
					label: '<i class="fa fa-times"></i> Cancel'
				},
				confirm: {
					label: '<i class="fa fa-check"></i> Confirm'
				}
			},
			callback: function (result) {
				if(result != false) {
                            $("#wait").css("display", "block");
                $.ajax({
                        type: 'POST',
                        url: '<?php echo API_PATH; ?>delete_user.php',
						data:{id:id},
                        success:function(data){ 
                            if($.trim(data) == 'Deleted'){
								$.notify("Record Deleted Successfully.", {
									type: 'success',
									offset: {
										x: 50,
										y: 100
									},
									animate: {
										enter: 'animated fadeInRight',
										exit: 'animated fadeOutRight'
									}
								});
								setTimeout(function(){ 
									location.reload();
								},3000);
							}
							else{
								$.notify("Error in deleting record.", {
									type: 'danger',
									offset: {
										x: 50,
										y: 100
									},
									animate: {
										enter: 'animated fadeInRight',
										exit: 'animated fadeOutRight'
									}
								});
							}
                        },
                        error: function(data) { 
                            alert("Error occured.please try again".data);
                        }

                     });
                }
			}
		});	
	});
	var profile_error;
	$("body").on("click","#btn-save",function(){
		profile_error = new Array;

		var name_var = $("#name").val();
		if($.trim(name_var) == '')
		{
			profile_error.push("name");	
		}
		else
		{
			$("#name").removeClass("error-border");
		}		
		
		var mobile = $("#mobile").val();
		if($.trim(mobile) != '')
		{
			if(!checkMobile(mobile))
			{
				profile_error.push("mobile");	
			}
			else{
				$("#mobile").removeClass("error-border");
			}
		}
		else
		{
			$("#mobile").removeClass("error-border");
		}
		var userName = $("#userName").val();
		if($.trim(userName) == '')
		{
			profile_error.push("userName");	
		}
		else
		{
			$("#pIduserName").removeClass("error-border");
		}
		
		var password = $("#password").val();
		if($.trim(userName) == '')
		{
			profile_error.push("password");	
		}
		else
		{
			$("#password").removeClass("error-border");
		}
		
		var idNo = $("#idNo").val();
		if($.trim(idNo) == '')
		{
			profile_error.push("idNo");	
		}
		else
		{
			$("#idNo").removeClass("error-border");
		}

		if(profile_error.length>0 ) 
		{
			var i, currentElem;
			for( i = 0, l = profile_error.length; i < l; i++ ) 
			{
				currentElem = profile_error[i];//alert(currentElem);
				$("#"+currentElem).addClass("error-border");
			}
			return false;
	
		}
		else
		{	
			//$(this).addClass('disabled');
			//$("#wait").css("display", "block");
			var datastring=$("#create-form").serializeArray(); 
			$.ajax({
				type: 'POST',
				url: '<?php echo API_PATH; ?>save_user.php',
				data:datastring,
				success:function(data){ 
					//alert(data);console.log(data);
					$("#modal-list").modal('hide');
					$("#wait").css("display", "none");
					
					if($.trim(data)=='Error'){
						$(this).removeClass('disabled');
						$.notify("Error in saving data. Please try again.", {
							type: 'danger',
							offset: {
								x: 50,
								y: 100
							},
							animate: {
								enter: 'animated fadeInRight',
								exit: 'animated fadeOutRight'
							}
						});
						return false;
					}
					else{
						
						$.notify("User Details saved successfully.", {
							type: 'success',
							offset: {
								x: 50,
								y: 100
							},
							animate: {
								enter: 'animated fadeInRight',
								exit: 'animated fadeOutRight'
							}
						});
						
						setTimeout(function(){ 
							location.reload();
						},3000);
						
					}
		
								
				},
				error: function(data) { 
					alert("Error occured.please try again".data);
				}
			});
		}
	});

	function checkMobile(mobile) {
		var filter = /^[0-9]*$/;
		if (filter.test(mobile)){
		  return true;
		}
		else{
		  return false;
		}
	}
});
</script>
</body>
</html>
